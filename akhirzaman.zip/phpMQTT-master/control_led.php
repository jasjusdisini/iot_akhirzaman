<?php
require_once 'phpMQTT.php';

$server   = 'mqtt.revolusi-it.com';
$port     = 1883;
$username = 'usm';
$password = 'usmjaya1';
$clientId = 'iot/G.231.22.0152' . rand();

$topicCmd = 'cmd/G.231.22.0152'; // Pastikan ESP8266 subscribe ke topik ini

// Ambil nilai dari parameter GET
$level = isset($_GET['level']) ? intval($_GET['level']) : 0;

// Siapkan payload JSON
$payload = json_encode([
    'LED' => $level
]);

// Buat koneksi MQTT
$mqtt = new Bluerhinos\phpMQTT($server, $port, $clientId);

if (!$mqtt->connect(true, NULL, $username, $password)) {
    echo "❌ Gagal konek ke broker MQTT.";
    exit();
}

// Publish data ke ESP
$mqtt->publish($topicCmd, $payload, 0);
$mqtt->close();

echo "✅ Perintah LED dengan level $level berhasil dikirim.";
?>
